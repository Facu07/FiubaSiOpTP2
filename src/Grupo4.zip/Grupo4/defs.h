#ifndef DEFS_H_
#define DEFS_H_

#define CANT_ORILLAS 4
#define NORTE 1
#define SUR 2
#define ESTE 3
#define OESTE 4



#endif /* DEFS_H_ */
