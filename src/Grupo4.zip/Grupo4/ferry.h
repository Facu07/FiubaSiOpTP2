struct Ferry{
        int kmax, k, n, cantVehiculos;
        int rutaActual;
};
Ferry ferry;


