struct Vehiculo{
        int ID;
        int k;
        int orilla;
};


